#ifndef JLINEWIDGET_H
#define JLINEWIDGET_H

#include <QWidget>
#include <vector>
#include "StockData.h"

class JLineWidget : public QWidget
{
    Q_OBJECT

public:
    explicit JLineWidget(QWidget *parent = nullptr);
    void setStockData(const std::vector<StockData>& data);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    std::vector<StockData> stockData; // 存储 J 线相关的股票数据
};

#endif // JLINEWIDGET_H

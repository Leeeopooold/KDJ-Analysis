#include "KLineWidget.h"
#include <QPainter>
#include <QMouseEvent>
#include <QToolTip>
#include <limits>

KLineWidget::KLineWidget(QWidget *parent)
    : QWidget(parent), hoveredIndex(-1) {}

void KLineWidget::setStockData(const std::vector<StockData> &data)
{
    stockData = data;
    update(); // 触发重绘
}

void KLineWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (stockData.empty()) return;

    int width = this->width();
    int candleWidth = (width - 50) / stockData.size(); // 留出边距
    int index = (event->x() - 50) / candleWidth; // 减去坐标轴左边距

    if (index >= 0 && index < static_cast<int>(stockData.size())) {
        hoveredIndex = index;
        const StockData &stock = stockData[index];

        // 显示工具提示
        QString tooltip = QString("Date: %1\nOpen: %2\nHigh: %3\nLow: %4\nClose: %5\nVolume: %6")
                              .arg(QString::fromStdString(stock.date))
                              .arg(stock.open)
                              .arg(stock.high)
                              .arg(stock.low)
                              .arg(stock.close)
                              .arg(stock.volume);

        QToolTip::showText(event->globalPos(), tooltip, this);
    } else {
        hoveredIndex = -1;
        QToolTip::hideText();
    }

    update(); // 触发重绘
}

void KLineWidget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    // 绘制背景
    painter.fillRect(rect(), Qt::white);

    if (stockData.empty()) return;

    int width = this->width();
    int height = this->height();

    // 绘制坐标轴
    drawAxes(painter, width, height);

    int candleWidth = (width - 50) / stockData.size(); // 留出坐标轴的边距

    double minPrice = std::numeric_limits<double>::max();
    double maxPrice = std::numeric_limits<double>::min();

    for (const auto &stock : stockData) {
        minPrice = std::min(minPrice, stock.low);
        maxPrice = std::max(maxPrice, stock.high);
    }

    for (size_t i = 0; i < stockData.size(); ++i) {
        const auto &stock = stockData[i];
        int x = 50 + i * candleWidth + candleWidth / 2;
        int openY = height - 30 - static_cast<int>((stock.open - minPrice) / (maxPrice - minPrice) * (height - 50));
        int closeY = height - 30 - static_cast<int>((stock.close - minPrice) / (maxPrice - minPrice) * (height - 50));
        int highY = height - 30 - static_cast<int>((stock.high - minPrice) / (maxPrice - minPrice) * (height - 50));
        int lowY = height - 30 - static_cast<int>((stock.low - minPrice) / (maxPrice - minPrice) * (height - 50));

        QPen pen(stock.close >= stock.open ? Qt::red : Qt::green);
        painter.setPen(pen);

        // 绘制影线
        painter.drawLine(x, highY, x, lowY);

        // 绘制实体
        QRectF body(x - candleWidth / 4.0, std::min(openY, closeY),
                    candleWidth / 2.0, std::abs(closeY - openY));
        painter.drawRect(body);
        painter.fillRect(body, stock.close >= stock.open ? Qt::red : Qt::green);

        // 高亮悬停的 K 线
        if (hoveredIndex == static_cast<int>(i)) {
            painter.setBrush(QColor(255, 255, 0, 128)); // 黄色半透明
            painter.drawRect(body);
        }
    }

    // 绘制 D 线
    drawDLine(painter, width, height);

    // 绘制 J 线
    drawJLine(painter, width, height);
}

void KLineWidget::drawAxes(QPainter &painter, int width, int height)
{
    QPen axisPen(Qt::black);
    axisPen.setWidth(1);
    painter.setPen(axisPen);

    // 定义边距
    int marginLeft = 50;
    int marginBottom = 30;

    // 绘制 X 轴和 Y 轴
    painter.drawLine(marginLeft, height - marginBottom, width, height - marginBottom); // X 轴
    painter.drawLine(marginLeft, 0, marginLeft, height - marginBottom);               // Y 轴

    // 绘制 Y 轴刻度
    double minPrice = std::numeric_limits<double>::max();
    double maxPrice = std::numeric_limits<double>::min();

    for (const auto &stock : stockData) {
        minPrice = std::min(minPrice, stock.low);
        maxPrice = std::max(maxPrice, stock.high);
    }

    double range = maxPrice - minPrice;
    if (range == 0) range = 1;

    int numTicks = 5;
    for (int i = 0; i <= numTicks; ++i) {
        double value = minPrice + i * range / numTicks;
        int y = height - marginBottom - static_cast<int>((value - minPrice) / range * (height - marginBottom));
        painter.drawLine(marginLeft - 5, y, marginLeft, y);
        painter.drawText(5, y + 10, QString::number(value, 'f', 2));
    }

    // 绘制 X 轴刻度
    int numXTicks = 5;
    for (int i = 0; i <= numXTicks; ++i) {
        int index = i * (stockData.size() - 1) / numXTicks;
        int x = marginLeft + index * (width - marginLeft) / stockData.size();
        painter.drawLine(x, height - marginBottom, x, height - marginBottom + 5);
        painter.drawText(x - 50, height - 10, QString::fromStdString(stockData[index].date));
    }
}

void KLineWidget::drawDLine(QPainter &painter, int width, int height)
{
    if (stockData.empty()) return;

    double minD = std::numeric_limits<double>::max();
    double maxD = std::numeric_limits<double>::min();

    for (const auto &stock : stockData) {
        minD = std::min(minD, stock.dValue);
        maxD = std::max(maxD, stock.dValue);
    }

    double range = maxD - minD;
    if (range == 0) range = 1; // 避免除零

    QPen pen(Qt::blue);
    pen.setWidth(2);
    painter.setPen(pen);

    for (size_t i = 1; i < stockData.size(); ++i) {
        double x1 = 50 + (i - 1) * (width - 50) / (stockData.size() - 1);
        double y1 = height - 30 - ((stockData[i - 1].dValue - minD) / range * (height - 50));
        double x2 = 50 + i * (width - 50) / (stockData.size() - 1);
        double y2 = height - 30 - ((stockData[i].dValue - minD) / range * (height - 50));

        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
    }
}

void KLineWidget::drawJLine(QPainter &painter, int width, int height)
{
    if (stockData.empty()) return;

    double minJ = std::numeric_limits<double>::max();
    double maxJ = std::numeric_limits<double>::min();

    for (const auto &stock : stockData) {
        minJ = std::min(minJ, stock.jValue);
        maxJ = std::max(maxJ, stock.jValue);
    }

    double range = maxJ - minJ;
    if (range == 0) range = 1; // 避免除零

    QPen pen(Qt::yellow);
    pen.setWidth(2);
    painter.setPen(pen);

    for (size_t i = 1; i < stockData.size(); ++i) {
        double x1 = 50 + (i - 1) * (width - 50) / (stockData.size() - 1);
        double y1 = height - 30 - ((stockData[i - 1].jValue - minJ) / range * (height - 50));
        double x2 = 50 + i * (width - 50) / (stockData.size() - 1);
        double y2 = height - 30 - ((stockData[i].jValue - minJ) / range * (height - 50));

        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
    }
}

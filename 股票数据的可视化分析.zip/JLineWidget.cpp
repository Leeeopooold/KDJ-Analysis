#include "JLineWidget.h"
#include <QPainter>
#include <QPen>
#include <QDebug>

JLineWidget::JLineWidget(QWidget *parent)
    : QWidget(parent)
{
}

void JLineWidget::setStockData(const std::vector<StockData>& data)
{
    stockData = data;
    update(); // 触发重绘
}

void JLineWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    if (stockData.empty()) {
        return;
    }

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    QPen pen(Qt::yellow); // 设置 J 线为黄色
    pen.setWidth(2);
    painter.setPen(pen);

    double width = static_cast<double>(this->width());
    double height = static_cast<double>(this->height());
    double maxJ = -1e9, minJ = 1e9;

    // 找到 J 值的最大最小值用于缩放
    for (const auto& stock : stockData) {
        maxJ = std::max(maxJ, stock.jValue);
        minJ = std::min(minJ, stock.jValue);
    }

    double range = maxJ - minJ;
    if (range == 0) range = 1; // 避免除零

    // 绘制 J 线
    for (size_t i = 1; i < stockData.size(); ++i) {
        double x1 = (i - 1) * width / (stockData.size() - 1);
        double y1 = height - ((stockData[i - 1].jValue - minJ) / range * height);
        double x2 = i * width / (stockData.size() - 1);
        double y2 = height - ((stockData[i].jValue - minJ) / range * height);

        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
    }
}

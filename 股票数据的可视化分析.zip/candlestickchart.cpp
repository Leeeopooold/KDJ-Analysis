#include "candlestickchart.h"
#include <QPainter>
#include <QPen>
#include <QBrush>



CandlestickChart::CandlestickChart(QWidget *parent)
    : QWidget(parent)
{
    // 初始化时没有任何数据
}

void CandlestickChart::setData(const QVector<Candlestick>& newData)
{
    data = newData;  // 更新 K 线数据
    update();         // 调用 update() 触发重新绘制
}

void CandlestickChart::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    int chartWidth = width();
    int chartHeight = height();

    // 设置 K 线的宽度和间距
    int candleWidth = chartWidth / data.size() * 0.8;

    // 设置画笔
    QPen pen;
    pen.setColor(Qt::black);
    painter.setPen(pen);

    // 绘制每根 K 线
    for (int i = 0; i < data.size(); ++i) {
        const Candlestick &candle = data[i];

        // 计算每根 K 线的坐标位置
        int x = i * candleWidth + (chartWidth / data.size()) / 2;
        int openY = chartHeight - candle.open;  // Y坐标从底部开始
        int closeY = chartHeight - candle.close;
        int highY = chartHeight - candle.high;
        int lowY = chartHeight - candle.low;

        // 绘制影线（最高价和最低价）
        painter.drawLine(x, highY, x, lowY);

        // 绘制实体部分（开盘价到收盘价之间）
        QRect rect(x - candleWidth / 4, closeY, candleWidth / 2, openY - closeY);
        painter.fillRect(rect, candle.close > candle.open ? Qt::green : Qt::red);
    }
}

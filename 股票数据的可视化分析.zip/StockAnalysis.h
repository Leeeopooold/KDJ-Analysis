#ifndef STOCKANALYSIS_H
#define STOCKANALYSIS_H

#include <vector>
#include "StockData.h"

class StockAnalysis {
public:
    // 计算涨跌额和涨跌幅
    static void calculatePriceChange(std::vector<StockData> &data);

    // 计算 KDJ
    static void calculateKDJ(std::vector<StockData> &data, size_t N = 9, size_t M1 = 3, size_t M2 = 3);

    // 计算 BOLL
    static void calculateBOLL(std::vector<StockData> &data, size_t N = 20);

    // 计算收益率
    static std::vector<double> calculateReturns(const std::vector<StockData> &data);

    // 计算夏普比率
    static double calculateSharpeRatio(const std::vector<double> &returns);

    // 排序功能
    static void sortByPriceChangePct(std::vector<StockData> &data);
    static void sortBySharpeRatio(std::vector<StockData> &data);
};

#endif // STOCKANALYSIS_H

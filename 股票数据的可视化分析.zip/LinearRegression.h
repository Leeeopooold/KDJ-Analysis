#ifndef LINEAR_REGRESSION_H
#define LINEAR_REGRESSION_H

#include <vector>

class LinearRegression {
public:
    LinearRegression(double learningRate = 0.01, int iterations = 1000);

    void fit(const std::vector<std::vector<double>>& X, const std::vector<double>& y);
    std::vector<double> predict(const std::vector<std::vector<double>>& X);

private:
    std::vector<double> weights;
    double bias;
    double learningRate;
    int iterations;
};

#endif // LINEAR_REGRESSION_H

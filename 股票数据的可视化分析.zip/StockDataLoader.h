#ifndef STOCKDATALOADER_H
#define STOCKDATALOADER_H

#include <QString>
#include <vector>
#include "StockData.h"

class StockDataLoader {
public:
    std::vector<StockData> loadStockData(const QString &filename);
};

#endif // STOCKDATALOADER_H

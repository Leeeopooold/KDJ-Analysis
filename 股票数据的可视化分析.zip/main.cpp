#include "mainwindow.h"  // 包含主窗口的头文件，定义了 MainWindow 类
#include <QApplication>   // 包含 Qt 应用程序相关类的头文件

// 主函数：Qt 应用程序的入口
int main(int argc, char *argv[]) {
    // QApplication 是 Qt 应用程序的核心类，负责管理应用程序的控制流和主要设置
    QApplication a(argc, argv);

    // 创建主窗口对象
    MainWindow w;

    // 显示主窗口
    w.show();

    // 进入应用程序的事件循环
    // a.exec() 会保持程序运行，直到接收到退出事件
    return a.exec();
}

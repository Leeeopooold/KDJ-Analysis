#ifndef KLINEWIDGET_H
#define KLINEWIDGET_H

#include <QWidget>
#include <vector>
#include "StockData.h"

class KLineWidget : public QWidget
{
    Q_OBJECT

public:
    explicit KLineWidget(QWidget *parent = nullptr);
    void setStockData(const std::vector<StockData> &data);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;

private:
    void drawAxes(QPainter &painter, int width, int height); // 绘制坐标轴
    void drawDLine(QPainter &painter, int width, int height); // 绘制 D 线
    void drawJLine(QPainter &painter, int width, int height); // 绘制 J 线

    std::vector<StockData> stockData; // 存储股票数据
    int hoveredIndex;                 // 当前鼠标悬停的 K 线索引
};

#endif // KLINEWIDGET_H

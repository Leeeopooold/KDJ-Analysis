#include "StockAnalysis.h"
#include <algorithm>
#include <numeric>
#include <cmath>
#include <limits>

// 计算涨跌额和涨跌幅
void StockAnalysis::calculatePriceChange(std::vector<StockData> &data) {
    for (size_t i = 1; i < data.size(); ++i) {
        double priceChangeAmount = data[i].close - data[i - 1].close;
        data[i].priceChangeAmount = priceChangeAmount;
        data[i].priceChangePct = (priceChangeAmount / data[i - 1].close) * 100.0;
    }
}

// 计算 KDJ
void StockAnalysis::calculateKDJ(std::vector<StockData> &data, size_t N, size_t M1, size_t M2) {
    for (size_t i = N - 1; i < data.size(); ++i) {
        double highestHigh = -std::numeric_limits<double>::infinity();
        double lowestLow = std::numeric_limits<double>::infinity();

        for (size_t j = i - N + 1; j <= i; ++j) {
            highestHigh = std::max(highestHigh, data[j].high);
            lowestLow = std::min(lowestLow, data[j].low);
        }

        double rsv = (data[i].close - lowestLow) / (highestHigh - lowestLow) * 100.0;
        data[i].kValue = (rsv + (M1 - 1) * data[i - 1].kValue) / M1;
        data[i].dValue = (data[i].kValue + (M2 - 1) * data[i - 1].dValue) / M2;
        data[i].jValue = 3.0 * data[i].kValue - 2.0 * data[i].dValue;
    }
}

// 计算 BOLL
void StockAnalysis::calculateBOLL(std::vector<StockData> &data, size_t N) {
    for (size_t i = N - 1; i < data.size(); ++i) {
        double sumClose = 0.0;
        for (size_t j = i - N + 1; j <= i; ++j) {
            sumClose += data[j].close;
        }

        double movingAverage = sumClose / N;

        double sumSquaredDifferences = 0.0;
        for (size_t j = i - N + 1; j <= i; ++j) {
            sumSquaredDifferences += std::pow(data[j].close - movingAverage, 2);
        }

        double standardDeviation = std::sqrt(sumSquaredDifferences / N);
        data[i].bollUpper = movingAverage + 2.0 * standardDeviation;  // BOLL 上轨
    }
}

// 计算收益率
std::vector<double> StockAnalysis::calculateReturns(const std::vector<StockData> &data) {
    std::vector<double> returns;
    for (size_t i = 1; i < data.size(); ++i) {
        double dailyReturn = (data[i].close - data[i - 1].close) / data[i - 1].close;
        returns.push_back(dailyReturn);
    }
    return returns;
}

// 计算夏普比率
double StockAnalysis::calculateSharpeRatio(const std::vector<double> &returns) {
    double meanReturn = std::accumulate(returns.begin(), returns.end(), 0.0) / returns.size();

    double squaredDifferences = 0.0;
    for (double ret : returns) {
        squaredDifferences += std::pow(ret - meanReturn, 2);
    }

    double volatility = std::sqrt(squaredDifferences / returns.size());
    return (meanReturn / volatility);
}

// 排序功能
void StockAnalysis::sortByPriceChangePct(std::vector<StockData> &data) {
    std::sort(data.begin(), data.end(), [](const StockData &a, const StockData &b) {
        return a.priceChangePct > b.priceChangePct;
    });
}

void StockAnalysis::sortBySharpeRatio(std::vector<StockData> &data) {
    std::vector<double> returns = calculateReturns(data);
    double sharpeRatio = calculateSharpeRatio(returns);

    std::sort(data.begin(), data.end(), [&](const StockData &a, const StockData &b) {
        return calculateSharpeRatio(calculateReturns({a})) > calculateSharpeRatio(calculateReturns({b}));
    });
}

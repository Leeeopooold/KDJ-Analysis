
#include "DLineWidget.h"
#include <QPainter>
#include <QPen>
#include <QDebug>

DLineWidget::DLineWidget(QWidget *parent)
    : QWidget(parent)
{
}

void DLineWidget::setStockData(const std::vector<StockData>& data)
{
    stockData = data;
    update(); // Trigger a repaint
}

void DLineWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    if (stockData.empty()) {
        return;
    }

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    QPen pen(Qt::blue);
    pen.setWidth(2);
    painter.setPen(pen);

    double width = static_cast<double>(this->width());
    double height = static_cast<double>(this->height());
    double maxD = -1e9, minD = 1e9;

    // Find max and min D values for scaling
    for (const auto& stock : stockData) {
        if (stock.dValue > maxD) maxD = stock.dValue;
        if (stock.dValue < minD) minD = stock.dValue;
    }

    double range = maxD - minD;
    if (range == 0) range = 1; // Avoid division by zero

    // Draw D line
    for (size_t i = 1; i < stockData.size(); ++i) {
        double x1 = (i - 1) * width / (stockData.size() - 1);
        double y1 = height - ((stockData[i - 1].dValue - minD) / range * height);
        double x2 = i * width / (stockData.size() - 1);
        double y2 = height - ((stockData[i].dValue - minD) / range * height);

        painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
    }
}



#ifndef STOCKDATA_H
#define STOCKDATA_H

#include <string>


class StockData {
public:
    std::string date;  // 日期
    double open;       // 开盘价
    double high;       // 最高价
    double low;        // 最低价
    double close;      // 收盘价
    long long volume;  // 成交量

    double priceChangeAmount;  // 涨跌额
    double priceChangePct;     // 涨跌幅
    double kValue;             // K值
    double dValue;             // D值
    double jValue;             // J值
    double bollUpper;          // BOLL 上轨

    StockData()
        : open(0), high(0), low(0), close(0), volume(0),
        priceChangeAmount(0), priceChangePct(0),
        kValue(0), dValue(0), jValue(0), bollUpper(0) {}
};

#endif // STOCKDATA_H

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "StockDataLoader.h"
#include "StockAnalysis.h"
#include "LinearRegression.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QTableWidgetItem>
#include <QVBoxLayout>
#include <QDebug>
#include<iostream>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 初始化 KLineWidget 并添加到布局
    kLineWidget = new KLineWidget(this);

    if (ui->verticalLayout->layout()) {
        ui->verticalLayout->addWidget(kLineWidget);
    } else {
        qDebug() << "Error: verticalLayout not found in UI.";
    }

    // 启用表格的排序功能
    ui->tableWidget->setSortingEnabled(true);
    ui->tableWidget->horizontalHeader()->setSortIndicatorShown(true);

    // 连接加载按钮的信号到槽函数
    connect(ui->loadButton, &QPushButton::clicked, this, &MainWindow::loadData);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::loadData()
{
    QString fileName = QFileDialog::getOpenFileName(this, "Open CSV File", "", "CSV Files (*.csv);;All Files (*)");
    if (fileName.isEmpty()) {
        return;
    }

    // 使用 StockDataLoader 加载数据
    StockDataLoader loader;
    stockData = loader.loadStockData(fileName);

    if (stockData.empty()) {
        QMessageBox::warning(this, "Error", "No valid data loaded!");
        return;
    }

    // 计算技术指标
    StockAnalysis::calculatePriceChange(stockData);
    StockAnalysis::calculateKDJ(stockData);
    StockAnalysis::calculateBOLL(stockData);

    // 计算夏普比率
    std::vector<double> returns = StockAnalysis::calculateReturns(stockData);
    double sharpeRatio = StockAnalysis::calculateSharpeRatio(returns);

    // 将数据展示到表格
    ui->tableWidget->setRowCount(stockData.size());
    ui->tableWidget->setColumnCount(12); // 新增列：涨跌额、涨跌幅、K、D、BOLL 上轨
    ui->tableWidget->setHorizontalHeaderLabels({"Date", "Open", "High", "Low", "Close", "Volume", "Price Change ($)", "Price Change (%)", "K", "D", "J", "BOLL Upper"});

    for (int i = 0; i < stockData.size(); ++i) {
        const StockData& stock = stockData[i];
        ui->tableWidget->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(stock.date)));
        ui->tableWidget->setItem(i, 1, new QTableWidgetItem(QString::number(stock.open)));
        ui->tableWidget->setItem(i, 2, new QTableWidgetItem(QString::number(stock.high)));
        ui->tableWidget->setItem(i, 3, new QTableWidgetItem(QString::number(stock.low)));
        ui->tableWidget->setItem(i, 4, new QTableWidgetItem(QString::number(stock.close)));
        ui->tableWidget->setItem(i, 5, new QTableWidgetItem(QString::number(stock.volume)));
        ui->tableWidget->setItem(i, 6, new QTableWidgetItem(QString::number(stock.priceChangeAmount, 'f', 2)));
        ui->tableWidget->setItem(i, 7, new QTableWidgetItem(QString::number(stock.priceChangePct, 'f', 2)));
        ui->tableWidget->setItem(i, 8, new QTableWidgetItem(QString::number(stock.kValue, 'f', 2)));
        ui->tableWidget->setItem(i, 9, new QTableWidgetItem(QString::number(stock.dValue, 'f', 2)));
        ui->tableWidget->setItem(i, 10, new QTableWidgetItem(QString::number(stock.jValue, 'f', 2)));
        ui->tableWidget->setItem(i, 11, new QTableWidgetItem(QString::number(stock.bollUpper, 'f', 2)));
    }

    // 将数据传递给 KLineWidget，绘制 K 线图及叠加的 D 线和 J 线
    kLineWidget->setStockData(stockData);

    // 进行异常检测
    detectAnomalies(stockData);

    // 股票价格预测（线性回归）
    std::vector<std::vector<double>> X;
    std::vector<double> y;

    for (size_t i = 0; i < stockData.size() - 1; ++i) {
        X.push_back({stockData[i].open, stockData[i].high, stockData[i].low, static_cast<double>(stockData[i].volume)});
        y.push_back(stockData[i + 1].close); // 目标是下一天的收盘价
    }

    // 训练线性回归模型
    LinearRegression model(0.01, 1000);
    model.fit(X, y);

    // 预测未来一天的收盘价
    std::vector<double> lastDayFeatures = {stockData.back().open, stockData.back().high, stockData.back().low, static_cast<double>(stockData.back().volume)};
    double predictedPrice = model.predict({lastDayFeatures})[0];

    std::cout << "Nextday Open: " << predictedPrice << std::endl;
}

void MainWindow::detectAnomalies(const std::vector<StockData>& stockData) {
    for (size_t i = 1; i < stockData.size(); ++i) {
        double priceChangePct = (stockData[i].close - stockData[i - 1].close) / stockData[i - 1].close * 100.0;
        double volumeChangePct = (stockData[i].volume - stockData[i - 1].volume) / (double)stockData[i - 1].volume * 100.0;

        if (std::abs(priceChangePct) > 10 || std::abs(volumeChangePct) > 50) {
            std::cout << "Abnormal Stock:Date" << stockData[i].date
                      << ", Pricechangepct=" << priceChangePct << "%"
                      << ", VolumeChangePct=" << volumeChangePct << "%" << std::endl;
        }
    }
}

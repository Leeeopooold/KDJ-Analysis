#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>
#include "StockData.h"
#include "LinearRegression.h"
#include "KLineWidget.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void loadData(); // 槽函数，用于加载数据
    void detectAnomalies(const std::vector<StockData>& stockData); // 异常检测

private:
    Ui::MainWindow *ui;
    std::vector<StockData> stockData; // 存储股票数据
    KLineWidget *kLineWidget;         // 用于显示 K 线图的控件，包含 K、D 和 J 线
};

#endif // MAINWINDOW_H

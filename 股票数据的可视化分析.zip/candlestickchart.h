#ifndef CANDLESTICKCHART_H
#define CANDLESTICKCHART_H

#include <QWidget>
#include <QVector>
#include <QPainter>



// 定义一个结构体来存储每根 K 线的四个重要数据
struct Candlestick {
    float open;  // 开盘价
    float close; // 收盘价
    float high;  // 最高价
    float low;   // 最低价
};

class CandlestickChart : public QWidget
{
    Q_OBJECT

public:
    explicit CandlestickChart(QWidget *parent = nullptr);  // 构造函数

    // 设置 K 线数据的方法
    void setData(const QVector<Candlestick>& data);

protected:
    // 重写绘制事件，使用 QPainter 绘制图形
    void paintEvent(QPaintEvent *event) override;

private:
    QVector<Candlestick> data;  // 存储 K 线数据
};


#endif // CANDLESTICKCHART_H

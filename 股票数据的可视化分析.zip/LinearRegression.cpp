#include "LinearRegression.h"
#include <cmath>

LinearRegression::LinearRegression(double learningRate, int iterations)
    : learningRate(learningRate), iterations(iterations), bias(0) {}

void LinearRegression::fit(const std::vector<std::vector<double>>& X, const std::vector<double>& y) {
    int n_samples = X.size();
    int n_features = X[0].size();
    weights.resize(n_features, 0.0);

    for (int it = 0; it < iterations; ++it) {
        std::vector<double> y_pred(n_samples, bias);
        for (int i = 0; i < n_samples; ++i) {
            for (int j = 0; j < n_features; ++j) {
                y_pred[i] += weights[j] * X[i][j];
            }
        }

        // Compute gradients
        std::vector<double> dw(n_features, 0.0);
        double db = 0.0;
        for (int i = 0; i < n_samples; ++i) {
            double error = y_pred[i] - y[i];
            for (int j = 0; j < n_features; ++j) {
                dw[j] += error * X[i][j];
            }
            db += error;
        }

        // Update weights and bias
        for (int j = 0; j < n_features; ++j) {
            weights[j] -= learningRate * dw[j] / n_samples;
        }
        bias -= learningRate * db / n_samples;
    }
}

std::vector<double> LinearRegression::predict(const std::vector<std::vector<double>>& X) {
    std::vector<double> predictions(X.size(), bias);
    for (size_t i = 0; i < X.size(); ++i) {
        for (size_t j = 0; j < X[i].size(); ++j) {
            predictions[i] += weights[j] * X[i][j];
        }
    }
    return predictions;
}

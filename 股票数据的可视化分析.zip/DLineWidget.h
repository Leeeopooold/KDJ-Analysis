
#ifndef DLINEWIDGET_H
#define DLINEWIDGET_H

#include <QWidget>
#include <vector>
#include "StockData.h"

class DLineWidget : public QWidget
{
    Q_OBJECT

public:
    explicit DLineWidget(QWidget *parent = nullptr);
    void setStockData(const std::vector<StockData>& data);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    std::vector<StockData> stockData; //存储D线相关的股票数据
};

#endif // DLINEWIDGET_H

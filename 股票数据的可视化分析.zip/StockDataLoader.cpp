#include "StockDataLoader.h"
#include <QFile>
#include <QTextStream>
#include <QStringList>
#include <QDebug>
#include <set>
#include <limits>

bool isValidNumber(double value) {
    return value > 0 && value < std::numeric_limits<double>::infinity();
}

std::vector<StockData> StockDataLoader::loadStockData(const QString &filename) {
    std::vector<StockData> data;
    QFile file(filename);

    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Failed to open file: " << filename;
        return data;
    }

    QTextStream in(&file);
    std::set<std::string> seenDates;

    if (!in.atEnd()) {
        in.readLine();  // Skip header
    }

    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(',');

        if (fields.size() >= 6) {
            StockData stock;
            stock.date = fields[0].toStdString();

            if (seenDates.find(stock.date) != seenDates.end()) {
                continue;  // Skip duplicate date
            }
            seenDates.insert(stock.date);

            stock.open = fields[1].toDouble();
            stock.high = fields[2].toDouble();
            stock.low = fields[3].toDouble();
            stock.close = fields[4].toDouble();
            stock.volume = fields[5].toLongLong();

            if (isValidNumber(stock.open) && isValidNumber(stock.high) &&
                isValidNumber(stock.low) && isValidNumber(stock.close) && stock.volume > 0) {
                data.push_back(stock);
            }
        }
    }

    file.close();
    return data;
}

